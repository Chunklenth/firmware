#! /bin/bash

# SATA SAS, Check the environment
check_env()
{
    echo -e "\033[0;34m Env is checking... \033[0m"
    x86_env=$(uname -a 2>/dev/null | grep -w "x86_64")
    arm_env=$(uname -a 2>/dev/null | grep -w "aarch64")
    pack_env=$(cat $currentdir/version.xml | grep "<ProcessorArchitecture>" | awk -F ">" '{print $2}' | awk -F "<" '{print $1}')
    if [ -n "${x86_env}" ] && [[ "$pack_env" == "x86" ]]
    then
        testtool="$currentdir/tools/tools_x86"
    elif [ -n "${arm_env}" ] && [[ "$pack_env" == "ARM" ]]
    then
        testtool="$currentdir/tools/tools_arm"
        hiraidadm="$testtool/hiraidadm"
    else
        local error_code=1
        local description="The script package and environment isn't matched"
        error_func $error_code "${description[*]}"
    fi

    storclitool="$testtool/storcli64"
    arcconf="$testtool/arcconf"
    sas3="$testtool/sas3ircu"
    smartool="$testtool/smartctl"
    sg_scan="$testtool/sg_scan"
    sg_inq="$testtool/sg_inq"
    [[ "$curInterface" == "SATA" ]] && hdparm="$testtool/hdparm"
    [[ "$curInterface" == "SAS" ]] && sg_update="$testtool/sg_write_buffer"

    # HBA2308 card use sas2ircu tools, 2308 don't match the arm
    # LSI SAS2308 RAID卡已EOS，sas2ircu工具已被禁用，无新版本发布，uTool去除适配2308卡
    raidcard=$(lspci | grep LSI | awk -F 'Symbios Logic' '{print $2}' | awk '{print $1}')
    if [[ "$raidcard" == "SAS2308" ]] && [ -n "${x86_env}" ]
    then
        local error_code=3
        local description="LSI SAS2308 RAID card does not support"
        error_func $error_code "${description[*]}"
    fi
}