#! /bin/bash

# Upgrade disk firmware under Hiraid
hiraid_fw_update()
{
    local eid_slot=$1
    local cidindex=$2
    local eid=$(echo ${eid_slot} | awk -F ":" '{print $1}')
    local slot=$(echo ${eid_slot} | awk -F ":" '{print $2}')
    local disk_firmware=$("$hiraidadm" c${cidindex}:e${eid}:s${slot} show | grep -w "Firmware Version" | awk -F "|" '{print $NF}' | grep -Po "\b.*\b")
    local disk_model=$("$hiraidadm" c${cidindex}:e${eid}:s${slot} show | grep -w "Model" | awk -F "|" '{print $NF}' | grep -Po "\b.*\b")
    local sn=$("$hiraidadm" c${cidindex}:e${eid}:s${slot} show | grep -w "Serial Number" | awk -F "|" '{print $NF}' | grep -Po "\b.*\b")

    # NULL check
    if [ -z "$disk_model" ] || [ -z "$disk_firmware" ]
    then
        local error_code=10
        local description="disk_firmware or disk_model that [${eid_slot}][Control_id:${cidindex}] is empty. Disk SN: $sn.$resume_res"
        error_func $error_code "${description[*]}"
    fi
    # Record scan on the disk
    echo "$disk_model : $disk_firmware" >> $currentdir/raid_drive_list.txt
    # Check whether tested disk model number in version.xml
    local version_config=$currentdir/version.xml
    local dependent_model=$(cat $version_config | grep -i "<Dependency model=\"${disk_model}\"")
    if [ -n "$dependent_model" ]; then
    	local version_tmp=$(cat $currentdir/version.xml | grep -iF "<Dependency model=\"${disk_model}\"" | awk -F "matchXML=\"" '{print $2}' | awk -F "\"" '{print $1}')
    	local version_config=$currentdir/$version_tmp
    	local bin_fw_list=($(cat $version_config | grep "<FileName>" | sed -e 's/\///g' | awk -F "<FileName>" '{print $2}' | sed -e 's/,/ /g'))
    fi
    local disk_model_part=$(echo "$disk_model" | awk '{print $NF}')
    local raid_model_check=$(cat $version_config | grep "<SupportModel>" | grep -i "$disk_model_part")
    if [ -n "$raid_model_check" ]
    then
        find_disk=1
        # Check the tested disk whether the firmware is the latest
        local new_firmware=$(cat $version_config | grep "<Version>" | sed 's/\///g' | awk -F "<Version>" '{print $2}')
        local check_new=$(echo "$new_firmware" | grep -w "$disk_firmware")
        if [ -z "$check_new" ]
        then
            local old_version=$(cat $version_config | grep "<RuleOldVersion>" | awk -F "</?RuleOldVersion>" '{print $2}')
            # Check whether need to check old version
            if [[ "$old_version" != "NULL" ]];then
                # Check whether disk current firmware in the history list
                check_xml $disk_firmware $disk_model $eid_slot $sn
                # Check XH disk current firmware in the history list
                local fwrule=$(cat $version_config | grep "<RuleOldVersion>" | awk -F "<RuleOldVersion>" '{print $2}' | awk -F ";" '{print $1}')
                local check_history_fw=$(echo "$fwrule" | egrep -wo "$disk_firmware")
                if [ -z "$check_history_fw" ]
                then
                    echo -e "The hard disk [model:$disk_model] is correct, but the hard disk firmware is not in the historical upgrade list." | tee -a $upgrade_log
                    return 0
                fi
            fi
            local vu_list=",HWE62ST3480L003N,HWE62ST3960L003N,HWE62ST31T9L003N,"
            local need_vu=$(echo "$vu_list" | grep ",$disk_model,")
            if [ -n "$need_vu" ]
			then
				send_vu_command $disk_firmware "hiraid" $cidindex $eid_slot
			fi

            # Began to upgrade the firmware
            echo -e "\033[0;32m     start $disk_model update firmware \033[0m" | tee -a $upgrade_log
            for bin_fw in ${bin_fw_list[@]}
            do
                sleep 10
                # Upgrade command/check firmware is tried three times
                for ((n=1;n<4;n++))
                do
                    sleep 2
                    "$hiraidadm" c${cidindex}:e${eid}:s${slot} update fw file=./fw/${bin_fw}
                    if [ $? -eq 0 ]
                    then
                        echo "$(log_time) No.$n fw update ${bin_fw} command execute success for ${eid_slot} under HIRAID_RAID_MODE" | tee -a $upgrade_log
                    else
                        echo "$(log_time) No.$n fw update ${bin_fw} command execute failed for ${eid_slot} under HIRAID_RAID_MODE" | tee -a $upgrade_log
                        echo "No.$n fw update ${bin_fw} command execute failed for ${eid_slot} under HIRAID_RAID_MODE" >> $error_log
                    fi
                    sleep 5
                    "$hiraidadm" c${cidindex}:e${eid}:s${slot} active fw
                    [ $? -eq 0 ] && echo "$(log_time) finish c${cidindex}:e${eid}:s${slot} ${bin_fw} activated" | tee -a $upgrade_log
                    # Before the query firmware, waiting for 10 s
                    sleep 10
                    local after_update_firmware=$("$hiraidadm" c${cidindex}:e${eid}:s${slot} show | grep -w "Firmware Version" | awk -F "|" '{print $NF}' | grep -Po "\b.*\b")
                    if [ -n "$after_update_firmware" ]
                    then
                        local check_new_fw=$(echo "${bin_fw}" | grep "$after_update_firmware")
                    fi
                    if [ "$after_update_firmware" == "$new_firmware" ]
                    then
                        echo "$(log_time) $eid_slot fw update to $new_firmware success SN: $sn" | tee -a $upgrade_log
                        break
                    elif [ -n "$check_new_fw" ]
                    then
                        echo "$(log_time) $eid_slot fw update to ${bin_fw} success SN: $sn" | tee -a $upgrade_log
                        break
                    elif [ $n -ge 3 ]
                    then
                        echo -e "\033[0;31m Model:${disk_model}[$eid_slot] SN:${sn} fw update to $new_firmware failed \033[0m" | tee -a $error_log
                        local error_code=7
                        local err_description="$(cat $error_log). $resume_res"
                        error_func $error_code "${err_description[*]}"
                    fi
                done
            done
            echo -e "\033[0;32m     finish $disk_model update to $new_firmware firmware \033[0m" | tee -a $upgrade_log
        else
            echo -e "\033[0;32m     raid $disk_model : $disk_firmware is newest firmware \033[0m" | tee -a $upgrade_log
        fi
        return 0
    else
        echo -e "\033[0;32m     $eid_slot($disk_model) is not in the configuration,Skipping it.... \033[0m" | tee -a $upgrade_log
    fi
    return 0

}
