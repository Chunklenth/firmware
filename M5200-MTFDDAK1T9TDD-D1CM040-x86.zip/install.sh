#!/bin/bash
#set -e
#****************************************************************
#  FileName  :  install
#  Version   :  1.0
#  Date      :  2019-08-17
#  Function  :  Upgrade SATA hard disk firmware under server
#****************************************************************
source ./log_time_common.sh
source ./create_resultxml_common.sh
source ./check_healthy_common.sh
source ./sas_sata_common.sh
source ./error_func_common.sh
source ./hiraid_fw_update_common.sh
source ./megaraid_fw_update_common.sh
source ./pch_fw_update_common.sh
source ./pmc_fw_update_common.sh
source ./add_permission_common.sh
source ./check_firmware_common.sh
source ./check_env_common.sh
if [ -f "vu_command.sh" ]
then
	source ./vu_command.sh
fi


# main
main()
{
    currentdir="."
    upgrade_log="$currentdir/work.log"
    error_log="$currentdir/sata_error.log"
    resume_log="$currentdir/sata_resume.log"
    echo "date: $(log_time)" > $upgrade_log
    echo "date: $(log_time)" > $error_log
    echo "date: $(log_time)" > $resume_log
    [ -f "${currentdir}/result.xml" ] && rm -f ${currentdir}/result.xml
    echo -e "\033[0;33m The Firmware program runs began \033[0m" | tee -a $upgrade_log
    find_disk=0

    check_env

    # x86 environment load driver
    [ -n "${x86_env}" ] && check_raid_drive

    add_permission

    check_firmware

    check_raid

    # Megaraid
    if [ "$megaraid_flag" -eq 1 ]
    then
        echo "" > $currentdir/raid_drive_list.txt
        for megar_cid in ${MEGAR_CID[@]}
        do
            # Judge IT card and remove(High version storcli64 utilities that can identify 3008IR card, remove together here)
            local bcm_product_name=$("$storclitool" /c${megar_cid} show | grep -wi "Product Name" | awk '{print $NF}' | grep -Eo '3008|IT$')
            [ -n "$bcm_product_name" ] && continue
            
            # Get all the slot number
            local eid_slot_all=($("$storclitool" /c${megar_cid} show | awk '/PD LIST/,/EID=/' | grep -P "\d+:\d+" | grep -wi "SATA" | grep "^[0-9]" | awk '{print $1}'))
            for ((p=0;p<${#eid_slot_all[@]};p++))
            do
                echo -e "\033[0;34m ${eid_slot_all[$p]} is testing... \033[0m" | tee -a $upgrade_log

                check_raid_healthy "megaraid" $megar_cid

                check_disk_healthy "megaraid" $megar_cid
        
                megaraid_fw_update ${eid_slot_all[$p]} $megar_cid
            done
        done
    fi

    # Hiraid
    if [ -n "$arm_env" ] && [ "$hiraid_flag" -eq 1 ]
    then
      echo "" > $currentdir/raid_drive_list.txt
      hiraidadm_cid=($("$hiraidadm" show allctrl | grep "Controller Id" | grep -Eo "[0-9]+"))
      for cid in ${hiraidadm_cid[@]}
      do
          local E_s_all=($("$hiraidadm" c${cid} show pdlist | grep -w "SATA" | awk '{print $2,$3}' | sed 's/ /:/g'))
          for ((p=0;p<${#E_s_all[@]};p++))
          do
              echo -e "\033[0;34m ${E_s_all[$p]} is testing... \033[0m" | tee -a $upgrade_log

              check_raid_healthy "hiraid" $cid

              check_disk_healthy "hiraid" $cid

              hiraid_fw_update ${E_s_all[$p]} "$cid"
          done
      done
    fi

    # PMC
    if [ "$pmc_flag" -eq 1 ]
    then
        echo "" > $currentdir/pmc_drive_list.txt
        # Obtain all PMC card number
        PMC_CID=($("$arcconf" list | egrep -io "Controller [0-9]+" | egrep -o "[0-9]+"))
        for pmc_cid in ${PMC_CID[@]}
        do
            # 1 : 8060，0 : not 8060
            local type_feature=0
            local check_type=$("$arcconf" list | grep -i "Controller $pmc_cid" | grep "8060")
            [ -n "$check_type" ] && local type_feature=1

            # Get all the slot number(e.g: 0,1 0,2)
            local pmc_all_disks=($($arcconf list ${pmc_cid} | grep -P "\d+,\d+" | grep -vi "Not Applicable" | egrep -o "[0-9]+,[0-9]+"))
            # Get all the slot number of SATA disk
            local specified_disks=($($arcconf list ${pmc_cid} | grep -P "\d+,\d+" | grep -wi "SATA" | grep -vi "Not Applicable" | egrep -o "[0-9]+,[0-9]+"))
            for ((num=0;num<${#specified_disks[@]};num++))
            do
                echo -e "\033[0;34m ${specified_disks[$num]} is testing... \033[0m" | tee -a $upgrade_log

                check_raid_healthy "pmc" $pmc_cid

                check_disk_healthy "pmc" $pmc_cid "${pmc_all_disks[*]}" $type_feature
        
                pmc_fw_update ${specified_disks[$num]} $pmc_cid $type_feature
            done
        done
    fi

    # HBA&PCH
    # Get sg device and remove virtual
    sg_all_src=($("$sg_scan" | awk -F ":" '{print $1}'))
    for temp in ${sg_all_src[@]}
    do
        [ -z "$($sg_scan -i | grep -wA1 $temp | grep -Ei "Virtual|USB")" ] && sg_all=("${sg_all[@]}" ${temp})
    done
    
    # Remove after the raid set of logical drive
    for item in ${sg_all[@]}
    do
        local sg_type=$("$sg_inq" $item | grep -wi "type" | awk '{print $NF}' | grep -wi "disk")
        local disk_sata=$("$sg_inq" $item | grep -wi "Vendor identification" | awk '{print $NF}' | grep -wi "ATA")
        local disk_identify1=$("$sg_inq" $item | grep -wi "Product identification" | awk -F ":" '{print $2}' | grep -Po "\b.*\b" | egrep -i "Logical|HW-SAS|AVAGO|LSI")
        if [ -n "$sg_type" ] && [ -n "$disk_sata" ] && [ -z "$disk_identify1" ]
        then
            disk_all=("${disk_all[@]}" ${item})
        fi
    done
    echo "" > $currentdir/direct_drive_list.txt
    for disk in ${disk_all[@]}
    do
        echo -e "\033[0;34m $disk is testing... \033[0m" | tee -a $upgrade_log

        for hba_cid in ${HBA_CID[@]}
        do
            check_raid_healthy "hba" $hba_cid
        done

        # Parameter cid is just a placeholder
        check_disk_healthy "hba" "cid" "${disk_all[*]}"

        pch_fw_update $disk
    done

    # Restore Raid background tasks
    resume_bt

    # 没有对应的盘
    if [ $find_disk -eq 0 ];then
        local error_code=11
        local description="No available device found."
        error_func $error_code "${description[*]}"
    fi

    local error_code=0
    local description="The Firmware program runs finished. $resume_res"
    error_func $error_code "${description[*]}"
}

main

