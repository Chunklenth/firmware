#! /bin/bash

# Handling errors
error_func()
{
    error_code=$1
    description=$2

    if [ "$error_code" -ne 0 ]
    then
        result="Fail"
        echo -e "\033[0;31m $(log_time) [Error ${error_code}] ${description} \033[0m" | tee -a $error_log
    else
        result="OK"
        echo -e "\033[0;33m ${description} \033[0m" | tee -a $upgrade_log
    fi
    create_resultxml
    exit ${error_code}
}