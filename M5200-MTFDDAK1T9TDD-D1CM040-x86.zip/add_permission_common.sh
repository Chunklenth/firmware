#! /bin/bash

# Tool to assign permissions
add_permission()
{
    tools=($(ls "$testtool"/))
    for tool in ${tools[@]}
    do
        chmod +x "$testtool"/"$tool"
    done
}