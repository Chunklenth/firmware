#!/bin/bash
curDir="."
curInterface=$(cat $curDir/version.xml | grep "<RpmName>" | awk -F "<RpmName>" '{print $2}' | awk -F "</RpmName>" '{print $1}')

# Check the hard disk health status
check_disk_healthy()
{
    local raid_type=$1
    local cid_index=$2
    local disk_all=($3)
    local type_feature=$4

    echo -e "\033[0;36m     Disk health is checking... \033[0m"
    if [[ "$raid_type" == "megaraid" ]]
    then
        # Access to the online state hard disk raid number
        local disk_onln_arr=($("$storclitool" /c${cid_index} show | awk '/PD LIST/,/EID=/' | grep -P "\d+:\d+" | grep -wi "$curInterface" | grep -wi "Onln" | awk '{print $4}'))
        # Get jbod state hard drive slot number
        local disk_jbod_arr=($("$storclitool" /c${cid_index} show | awk '/PD LIST/,/EID=/' | grep -P "\d+:\d+" | grep -wi "$curInterface" | grep -wi "JBOD" | awk '{print $1}'))
        if [ -n "$disk_onln_arr" ]
        then
            for disk_onln in ${disk_onln_arr[@]}
            do
                local logic_volumn=$("$storclitool" /c${cid_index}/v${disk_onln} show all | grep -wi "OS Drive Name" | awk '{print $NF}')
                [ -n "$logic_volumn" ] && break
            done
        elif [[ -z "$logic_volumn" && -n "$disk_jbod_arr" && "$curInterface" == "SATA" ]] || [[ -n "$disk_jbod_arr" && "$curInterface" == "SAS" ]]
        then
            # According to the model number of reverse matching logical drive
            for disk_jbod in ${disk_jbod_arr[@]}
            do
                local eid=$(echo "${disk_jbod}" | awk -F ":" '{print $1}')
                local slot=$(echo "${disk_jbod}" | awk -F ":" '{print $2}')
                local sn=$("$storclitool" /c${cid_index}/e${eid}/s${slot} show all | grep "^SN" | awk -F "=" '{print $2}' | grep -Po "\b.*\b")
                local disk_model=$("$storclitool" /c${cid_index}/e${eid}/s${slot} show all | grep "Model Number" | awk -F "=" '{print $2}' | grep -Po "\b.*\b")
                local disk_model_part=${disk_model::16}

                # Get all the logical drive of corresponding to the model
                local logic_volumn_arr=($("$sg_scan" -i | grep -wiB1 "$disk_model_part" | grep -Po "/dev/sg(\d+)"))
                for logic_volumn_member in ${logic_volumn_arr[@]}
                do
                    local sn_check=$("$sg_inq" --page=0x80 --export $logic_volumn_member | grep -wi "SCSI_IDENT_SERIAL" | awk -F "=" '{print $2}' | grep -Po "\b.*\b")
                    if [[ "$sn_check" == "$sn" ]]
                    then
                        local logic_volumn="$logic_volumn_member"
                        break
                    fi
                done
                [ -n "$logic_volumn" ] && break
            done
        fi
        if [ -n "$logic_volumn" ]
        then
            # Gets the current raid card DID all the hard disk
            local did_all=($("$storclitool" /c${cid_index} show | awk '/PD LIST/,/EID=/' | grep -wi "$curInterface" | grep -P "\d+:\d+" | awk '{print $2}'))
            for did in ${did_all[@]}
            do
                # check smart
                local disk_health_field=$("$smartool" -a -d sat+megaraid,${did} ${logic_volumn} | grep -Pwi "SMART[\s\S]+Health")
                if [[ $curInterface == "SAS" ]]
                then
                	local disk_health_field=$("$smartool" -a -d megaraid,${did} ${logic_volumn} | grep -Pwi "SMART[\s\S]+Health")
                fi
                if [ -n "$disk_health_field" ]
                then
                    local disk_health=$(echo "$disk_health_field" | egrep -wi "PASSED|OK")
                    if [ -z "$disk_health" ]
                    then
                        local disk_model=$("$smartool" -i -d sat+megaraid,${did} ${logic_volumn} | grep -wi "Device Model" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
                        local disk_sn=$("$smartool" -i -d sat+megaraid,${did} ${logic_volumn} | grep -wi "Serial Number" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
                        if [[ $curInterface == "SAS" ]]
                		then
                			local disk_model=$("$smartool" -i -d megaraid,${did} ${logic_volumn} | grep -wi "Device Model" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
                        	local disk_sn=$("$smartool" -i -d megaraid,${did} ${logic_volumn} | grep -wi "Serial Number" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
                		fi
                        # Restore Raid background tasks
                        resume_bt
                        local error_code=5
                        local description="$disk_health_field, Model:${disk_model} SN:${disk_sn} is not healthy, Please confirm the smart health of the disk. $resume_res"
                        error_func $error_code "${description[*]}"
                    fi
                fi
            done
        fi
    elif [[ "$raid_type" == "hba" ]]
    then
        # Check all the hard disk of smart information
        for disk_sg in ${disk_all[@]}
        do
            local disk_health_field=$("$smartool" -H ${disk_sg} | grep -Pwi "SMART[\s\S]+Health")
            if [ -n "$disk_health_field" ]
            then
                local disk_health=$(echo "$disk_health_field" | egrep -wi "PASSED|OK")
                if [ -z "$disk_health" ]
                then
                    local disk_model=$("$smartool" -i ${disk_sg} | grep -wi "Device Model" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
                    local disk_sn=$("$smartool" -i ${disk_sg} | grep -wi "Serial Number" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
                    # Restore Raid background tasks
                    resume_bt
                    local error_code=5
                    local description="$disk_health_field, Model:${disk_model} SN:${disk_sn} is not healthy, Please confirm the smart health of the disk. $resume_res"
                    error_func $error_code "${description[*]}"
                fi
            fi
        done
    elif [[ "$raid_type" == "pmc" ]]
    then
        # Gets the current raid card all the virtual disk letter(Online or Ready mode)
        local disk_onln_arr=($("$arcconf" getconfig ${cid_index} ld | grep -wi "Disk Name" | grep -wi "/dev/sd." | awk '{print $NF}'))

        # PMC8060 card need accurate access to drive
        if [ -n "$disk_onln_arr" ] && [ "$type_feature" -eq 0 ]
        then
            # Choose a virtual drive, provide logical channel to smart info
            local pmc_logic_volumn="${disk_onln_arr[0]}"
        fi
        for ((n=0;n<${#disk_all[@]};n++))
        do
            if [ -z "$pmc_logic_volumn" ] || [ "$type_feature" -eq 1 ]
            then
                # Choose the raid card under a logical drive letter, provide logical channel to smart info
                local pmc_disk_name=$("$arcconf" getconfig ${cid_index} pd | grep -wB10 "${disk_all[$n]}" | grep -wi "Disk Name" | awk '{print $NF}')
                if [ -n "$pmc_disk_name" ]
                then
                    local pmc_logic_volumn="$pmc_disk_name"
                else
                    # According to the model number of reverse matching logical drive
                    local sn=$("$arcconf" getconfig ${cid_index} pd | grep -wA10 "${disk_all[$n]}" | grep -wi "Serial number" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
                    local pmc_disk_model=$("$arcconf" getconfig ${cid_index} pd | grep -wA10 "${disk_all[$n]}" | grep -wi "Model" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
                    local pmc_model_part=${pmc_disk_model::16}

                    # Get all the logical drive of corresponding to the model
                    local pmc_logic_volumn_arr=($("$sg_scan" -i | grep -wiB1 "$pmc_model_part" | grep -Po "/dev/sg(\d+)"))
                    for pmc_logic_volumn_member in ${pmc_logic_volumn_arr[@]}
                    do
                        local sn_check=$("$sg_inq" --page=0x80 --export $pmc_logic_volumn_member | grep -wi "SCSI_IDENT_SERIAL" | awk -F "=" '{print $2}' | grep -Po "\b.*\b")
                        if [[ "$sn_check" == "$sn" ]]
                        then
                            local pmc_logic_volumn="$pmc_logic_volumn_member"
                            break
                        fi
                    done
                fi
            fi
            if [ -n "$pmc_logic_volumn" ]
            then
                if [ "$type_feature" -ne 1 ]
                then
                    local disk_health_field=$("$smartool" -a --device=cciss,${n} ${pmc_logic_volumn} | grep -Pwi "SMART[\s\S]+Health")
                else
                    # PMC 8060 card information command : smartctl -i /dev/sgx
                    local disk_health_field=$("$smartool" -a ${pmc_logic_volumn} | grep -Pwi "SMART[\s\S]+Health")
                fi
                if [ -n "$disk_health_field" ]
                then
                    local disk_health=$(echo "$disk_health_field" | egrep -wi "PASSED|OK")
                    if [ -z "$disk_health" ]
                    then
                        if [ "$type_feature" -ne 1 ]
                        then
                            local disk_model=$("$smartool" -i --device=cciss,${n} ${pmc_logic_volumn} | grep -wi "Device Model" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
                            local disk_sn=$("$smartool" -i --device=cciss,${n} ${pmc_logic_volumn} | grep -wi "Serial Number" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
                        else
                            local disk_model=$("$smartool" -i ${pmc_logic_volumn} | grep -wi "Device Model" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
                            local disk_sn=$("$smartool" -i ${pmc_logic_volumn} | grep -wi "Serial Number" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
                        fi
                        # Restore Raid background tasks
                        resume_bt
                        local error_code=5
                        local description="$disk_health_field, Model:${disk_model} SN:${disk_sn} is not healthy, Please confirm the smart health of the disk. $resume_res"
                        error_func $error_code "${description[*]}"
                    fi
                fi
            fi
        done
    elif [[ "$raid_type" == "hiraid" ]]
    then
        # check disk health
        local index_arr=($("$hiraidadm" c"$cid_index" show pdlist | awk '/Enc  Slot DID/,/Status =/' | grep -wi "$curInterface" | awk '{print $1}'))
        for index in ${index_arr[@]}
        do
            local prefail=($("$hiraidadm" c"$cid_index" show pdlist | awk '/Enc  Slot DID/,/Status =/' | grep -wi "$curInterface" | grep -Pw "^$index" | awk '{print $9}'))
            if [[ "$prefail" != "No" ]]
            then
                local eid_sid=($("$hiraidadm" c"$cid_index" show pdlist | awk '/Enc  Slot DID/,/Status =/' | grep -wi "$curInterface" | grep -Pw "^$index" | awk '{print "e"$2":s"$3}'))
                local disk_model=$("$hiraidadm" c"$cid_index":$eid_sid show | grep -P "^Model" | awk -F "|" '{print $NF}' | grep -Po "\b.*\b")
                local disk_sn=$("$hiraidadm" c"$cid_index":$eid_sid show | grep -i "Serial Number" | awk -F "|" '{print $NF}'| grep -Po "\b.*\b")
                local error_code=5
                local description="Model:${disk_model} SN:${disk_sn} is not healthy, Please confirm the smart health of the disk. $resume_res"
                error_func $error_code "${description[*]}"
            fi
        done
    fi
    return 0
}

# Check the raid group health status
check_raid_healthy()
{
    local raid_type=$1
    local cid_index=$2

    echo -e "\033[0;36m     Raid health is checking... \033[0m"
    if [[ "$raid_type" == "megaraid" ]]
    then
        # Check the background task
        local bt_values=($("$storclitool" /c${cid_index} show | grep -wiA30 -m 1 "BT" | grep -P "^\s" | awk '{print $8}'))
        for ((h=0;h<${#bt_values[@]};h++))
        do
            if [[ "${bt_values[$h]}" == "Y" ]]
            then
                local disk_id_arr=($("$storclitool" /c${cid_index} show | grep -wiA30 -m 1 "BT" | grep -P "^\s" | awk '{print $1}'))
                local v_id=$("$storclitool" /c${cid_index}/vall show | grep -i "RAID" | grep -Po "${disk_id_arr[$h]}/\d+" | awk -F "/" '{print $2}')
                # Suspend Raid background tasks
                echo -e "\033[0;36m     Detect the Raid group(/c${cid_index}/v${v_id}) has a background task, pausing... \033[0m"
                close_bt $cid_index $v_id
            fi
        done
        # Check all the virtual disk
        local virtual_state=($("$storclitool" /c${cid_index} show | grep -wP "\d+/\d+" | grep -i "RAID" | awk '{print $3}'))
        for state in ${virtual_state[@]}
        do
            if [[ "$state" != "Optl" ]]
            then
                # Restore Raid background tasks
                resume_bt
                local error_code=4
                local description="virtual_disk_state is $state, Megaraid ${cid_index} virtual_disk_state is is abnormal. $resume_res"
                error_func $error_code "${description[*]}"
            fi
        done
        # Check VD_Cache
        local vd_field=$("$storclitool" /c${cid_index} show all | grep -wi "VD Cache")
        if [ -n "$vd_field" ]
        then
            local cache_value=$(echo "$vd_field" | awk '{print $NF}' | grep -wi "No")
            if [ -z "$cache_value" ]
            then
                # Restore Raid background tasks
                resume_bt
                local error_code=4
                local description="$vd_field, Megaraid ${cid_index} VD_Cache is abnormal. $resume_res"
                error_func $error_code "${description[*]}"
            fi
        fi
    elif [[ "$raid_type" == "hba" ]]
    then
        # Check the background task
        local current_operation=($("$sas3" ${cid_index} status | grep -wi "Current operation" | awk '{print $NF}'))
        for task in ${current_operation[@]}
        do
            if [[ "$task" != "None" ]]
            then
                echo -e "\033[0;31m Error 4: current_operation is $task, background task is exist under HBA ${cid_index} raid_group \033[0m" | tee -a $error_log
            fi
        done
        # Check all the virtual disk
        local virtual_state=($("$sas3" ${cid_index} display | grep -wi "Status of volume" | awk '{print $5}'))
        for vir_state in ${virtual_state[@]}
        do
            if [[ "$vir_state" != "Okay" ]]
            then
                # Restore Raid background tasks
                resume_bt
                local error_code=4
                local description="virtual_disk_state is ${vir_state}, HBA ${cid_index} virtual_disk_state is abnormal. $resume_res"
                error_func $error_code "${description[*]}"
            fi
        done
        # Check all the physical disk
        local physical_state=($("$sas3" ${cid_index} display | awk '/Hard disk/,/Drive Type/' | grep -PwiB10 "Protocol[\S\s]+${curInterface}" | grep -wi "State" | awk '{print $3}'))
        for phy_state in ${physical_state[@]}
        do
            # Use -a or -o can only be used for connection to the multiple conditions []
            if [ "$phy_state" != "Ready" -a "$phy_state" != "Optimal" -a "$phy_state" != "Hot" ]
            then
                # Restore Raid background tasks
                resume_bt
                local error_code=4
                local description="physical_disk_state is $phy_state, HBA ${cid_index} physical_disk_state is abnormal. $resume_res"
                error_func $error_code "${description[*]}"
            fi
        done
    elif [[ "$raid_type" == "pmc" ]]
    then
        # Check the background task
        local background_check_field=$("$arcconf" getstatus ${cid_index} | grep -wi "Current operation")
        if [ -n "$background_check_field" ]
        then
            local background_check=$(echo "$background_check_field" | egrep -wi "None")
            if [ -z "$background_check" ]
            then
                echo -e "\033[0;31m Error 4: $background_check_field, background task is exist under PMC ${cid_index} raid_group \033[0m" | tee -a $error_log
            fi
        fi
        # Check the state of controller
        local controller_check_field=$("$arcconf" getconfig ${cid_index} ad | grep -wi "Controller Status")
        if [ -n "$controller_check_field" ]
        then
            local controller_check=$(echo "$controller_check_field" | egrep -wi "Optimal")
            if [ -z "$controller_check" ]
            then
                # Restore Raid background tasks
                resume_bt
                local error_code=4
                local description="$controller_check_field, PMC ${cid_index} Controller is abnormal. $resume_res"
                error_func $error_code "${description[*]}"
            fi
        fi
        # Check all the virtual disk
        local virtual_state=($("$arcconf" getconfig ${cid_index} ar | grep -wiA5 "Array Number" | grep -wi "Status" | awk '{print $NF}'))
        for state in ${virtual_state[@]}
        do
            if [[ "$state" != "Ok" ]]
            then
                # Restore Raid background tasks
                resume_bt
                local error_code=4
                local description="virtual_disk_state is $state, PMC ${cid_index} virtual_disk_state is abnormal. $resume_res"
                error_func $error_code "${description[*]}"
            fi
        done
    elif [[ "$raid_type" == "hiraid" ]]
    then
        # Check all the virtual disk
        local virtual_state=($("$hiraidadm" c${cid_index} show vdlist | grep -wiA30 -m 1 "VDID" | egrep -v "^-" | grep -vi "status"  | egrep -vi "normal[ ]+normal"))
        if [[ $curInterface == "SAS" ]]
        then
        	local virtual_state=($("$hiraidadm" c${cid_index} show vdlist | grep -wiA30 -m 1 "VDID" | egrep -v "^-" | egrep -v "^-" | grep -vi "status"  | egrep -vi "normal[ ]+normal"))
		fi
        if [ -n "${virtual_state}" ]
        then
            local error_code=4
            local description="virtual_disk_state is $state, HIRAID ${cid_index} virtual_disk_state is abnormal. $resume_res"
            error_func $error_code "${description[*]}"
        fi
        # Check the state of controller
        local controller_number=$("$hiraidadm" show allctrl | grep -Pwi "Controllers\s+Number\s+=" | awk -F "=" '{print $NF}'| grep -Po "\b.*\b")
        local controller_id=($("$hiraidadm" show allctrl | grep -Pwi "Controller\s+Id" | awk -F '|' '{print $NF}' | grep -Po "\b.*\b"))
        if [[ "$controller_number" -ne "${#controller_id[@]}" ]]
        then
            local error_code=4
            local description="HIRAID Controller is abnormal. $resume_res"
            error_func $error_code "${description[*]}"
        fi
    fi
    return 0
}
