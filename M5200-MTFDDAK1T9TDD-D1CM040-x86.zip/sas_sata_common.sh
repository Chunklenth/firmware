#!/bin/bash

spinup_func()
{
    local cid=$1
    local eid=$2
    local slot=$3
    local spinup_value=$("$storclitool" /c${cid}/e${eid}/s${slot} show all | grep -w "${eid}:${slot}" | awk '{print $(NF-1)}')
    if [[ -n "${spinup_value}" ]] && [[ "${spinup_value}" == "D" ]]
    then
        "$storclitool" /c${cid}/e${eid}/s${slot} spindown
        sleep 2
        "$storclitool" /c${cid}/e${eid}/s${slot} spinup
    fi
}

# check disk firmware in history list
check_xml(){
  local current_firmware="$1"
  local disk_model="$2"
  local disk="$3"
  local sn="$4"
  local resume_res="$5"
  local firmwarecompare=$(cat $currentdir/version.xml | grep "<RuleOldVersion>" | grep -i "$current_firmware")
  if [ -z "$firmwarecompare" ]
  then
    resume_bt
    local error_code=6
    local description="[$disk_model][$disk] disk fw $current_firmware not in history_fw, Disk SN: $sn $resume_res"
    error_func $error_code "${description[*]}"
  fi
}


# Suspend Raid background tasks
close_bt()
{
    local cid_index=$1
    local raid_id=$2

    # check bgi
    local check_bgi=$("$storclitool" /c${cid_index}/v${raid_id} show bgi | grep "In progress")
    if [ -n "$check_bgi" ]
    then
        "$storclitool" /c${cid_index}/v${raid_id} pause bgi > command_result.log
        local res=$(cat command_result.log | grep -i "Status =" | grep -Pio "Success")
        if [ -n "$res" ]
        then
            echo -e "\033[0;36m     c${cid_index}/v${raid_id} bgi pause success \033[0m" | tee -a $upgrade_log
            bgi_arr=(${bgi_arr[@]} "${cid_index}_${raid_id}")
        else
            echo -e "\033[0;31m     c${cid_index}/v${raid_id} bgi pause failure \033[0m" | tee -a $error_log
        fi
    fi

    # check patrolread
    local check_pr=$("$storclitool" /c${cid_index} show patrolread | grep -i "PR Current State" | grep -i "Active")
    if [ -n "$check_pr" ]
    then
        local check_mode=$("$storclitool" /c${cid_index} show patrolread | grep -i "PR Mode" | grep -io "Disable")
        if [ -n "$check_mode" ]
        then
            "$storclitool" /c${cid_index} set patrolread=on mode=manual > command_result.log
            local res=$(cat command_result.log | grep -i "Status =" | grep -Pio "Success")
            if [ -n "$res" ]
            then
                echo -e "\033[0;36m     c${cid_index} mode_switch success \033[0m" | tee -a $upgrade_log
                pr_mode_arr=(${pr_mode_arr[@]} ${cid_index})
            else
                echo -e "\033[0;31m     c${cid_index} mode_switch failure \033[0m" | tee -a $error_log
            fi
            sleep 2
        fi
        "$storclitool" /c${cid_index} pause patrolread > command_result.log
        local res=$(cat command_result.log | grep -i "Status =" | grep -Pio "Success")
        if [ -n "$res" ]
        then
            echo -e "\033[0;36m     c${cid_index} patrolread pause success \033[0m" | tee -a $upgrade_log
            pr_arr=(${pr_arr[@]} ${cid_index})
        else
            echo -e "\033[0;31m     c${cid_index} patrolread pause failure \033[0m" | tee -a $error_log
        fi
    fi

    # check cc
    local check_cc=$("$storclitool" /c${cid_index}/v${raid_id} show cc | grep "In progress")
    if [ -n "$check_cc" ]
    then
        "$storclitool" /c${cid_index}/v${raid_id} pause cc > command_result.log
        local res=$(cat command_result.log | grep -i "Status =" | grep -Pio "Success")
        if [ -n "$res" ]
        then
            echo -e "\033[0;36m     c${cid_index}/v${raid_id} cc pause success \033[0m" | tee -a $upgrade_log
            cc_arr=(${cc_arr[@]} "${cid_index}_${raid_id}")
        else
            echo -e "\033[0;31m     c${cid_index}/v${raid_id} cc pause failure \033[0m" | tee -a $error_log
        fi
    fi
}


# Restore Raid background tasks
resume_bt()
{
    for cid_raid in ${bgi_arr[@]}
    do
        local cid_index=$(echo $cid_raid | awk -F "_" '{print $1}')
        local raid_id=$(echo $cid_raid | awk -F "_" '{print $2}')
        "$storclitool" /c${cid_index}/v${raid_id} resume bgi > command_result.log
        local res=$(cat command_result.log | grep -i "Status =" | grep -Pio "Success")
        if [ -n "$res" ]
        then
            echo -e "\033[0;33m c${cid_index}/v${raid_id} bgi resume success \033[0m"
        else
            echo "bgi : c${cid_index}/v${raid_id}" >> $resume_log
        fi
    done

    for cid_index in ${pr_arr[@]}
    do
        "$storclitool" /c${cid_index} resume patrolread > command_result.log
        local res=$(cat command_result.log | grep -i "Status =" | grep -Pio "Success")
        if [ -n "$res" ]
        then
            echo -e "\033[0;33m c${cid_index} patrolread resume success \033[0m"
        else
            echo "patrolread : c${cid_index}" >> $resume_log
        fi
    done
    for pr_mode in ${pr_mode_arr[@]}
    do
        "$storclitool" /c${cid_index} set patrolread=off > command_result.log
        local res=$(cat command_result.log | grep -i "Status =" | grep -Pio "Success")
        if [ -n "$res" ]
        then
            echo -e "\033[0;33m c${cid_index} patrolread mode_switch success \033[0m"
        else
            echo "patrolread mode : c${cid_index}" >> $resume_log
        fi
    done

    for cid_raid in ${cc_arr[@]}
    do
        local cid_index=$(echo $cid_raid | awk -F "_" '{print $1}')
        local raid_id=$(echo $cid_raid | awk -F "_" '{print $2}')
        "$storclitool" /c${cid_index}/v${raid_id} resume cc > command_result.log
        local res=$(cat command_result.log | grep -i "Status =" | grep -Pio "Success")
        if [ -n "$res" ]
        then
            echo -e "\033[0;33m c${cid_index}/v${raid_id} cc resume success \033[0m"
        else
            echo "cc : c${cid_index}/v${raid_id}" >> $resume_log
        fi
    done

    # Raid background tasks without full recovery, the error to exit
    if [ -n "$(cat $resume_log | grep -E "bgi|patrolread|cc")" ]
    then
        echo -e "\033[0;31m The Raid background tasks not fully recovered \033[0m" | tee -a $error_log
        resume_res="The Raid background tasks not fully recovered, need to manually restore. $(cat $resume_log)"
    fi
}



# Check whether the raid card support
check_raid()
{
    echo -e "\033[0;34m Raid Type is checking... \033[0m"
    # set Raid flag
    megaraid_flag=0
    hiraid_flag=0
    pmc_flag=0

    # Read the version file support raid card information
    support_raid_infos=($(cat $currentdir/version.xml | grep "<ObjectID>" | sed -e 's/\///g' | awk -F "<ObjectID>" '{print $2}' | sed -e 's/;/ /g'))

    # Get all the megaraid card number
    MEGAR_CID=($("$storclitool" /call show | grep "Controller ="| grep -Eo "[0-9]+"))
    for megar_cid in ${MEGAR_CID[@]}
    do
        # Out of 3008
        local megar_name=$("$storclitool" /c${megar_cid} show | grep -wi "Product Name" | awk -F "=" '{print $2}' | sed 's/ //g')
        [ -n "$(echo $megar_name | grep -o '3008')" ] && continue
        echo -e "\033[0;36m     Megaraid $megar_cid is found \033[0m" | tee -a $upgrade_log
        megaraid_flag=1
        # Obtain the corresponding raid card VID DID SVID SDID
        vdss=(vid did svid sdid)
        megar_vdss_raw=($("$storclitool" /c${megar_cid} show | egrep -w "Vendor Id|Device Id|SubVendor Id|SubDevice Id" | awk '{print $NF}'))
        for ((i=0;i<${#megar_vdss_raw[@]};i++))
        do
            local length=$(echo ${#megar_vdss_raw[$i]})
            if [[ "$length" == "5" ]]
            then
                eval ${vdss[$i]}=$(echo "${megar_vdss_raw[$i]}" | sed 's/0x/0x0/')
            elif [[ "$length" == "4" ]]
            then
                eval ${vdss[$i]}=$(echo "${megar_vdss_raw[$i]}" | sed 's/0x/0x00/')
            elif [[ "$length" == "3" ]]
            then
                eval ${vdss[$i]}=$(echo "${megar_vdss_raw[$i]}" | sed 's/0x/0x000/')
            else
                eval ${vdss[$i]}="${megar_vdss_raw[$i]}"
            fi
        done
        raid_identify_megar="$vid:$did:$svid:$sdid"
        match_raid=$(echo "${support_raid_infos[@]}" | grep -wi "$raid_identify_megar")
        if [ -z "$match_raid" ]
        then
            local error_code=3
            local description="Megaraid controller Numbers for $megar_cid card does not support"
            error_func $error_code "${description[*]}"
        fi
    done

    # Get all the HBA card number
    HBA_CID=($("$sas3" list | grep -A5 "Index" | awk '{print $1}' | grep -Ew "[0-9]+"))
    for hba_cid in ${HBA_CID[@]}
    do
        echo -e "\033[0;36m     HBA $hba_cid is found \033[0m" | tee -a $upgrade_log
        # Obtain the corresponding raid card VID DID SVID SDID
        vdss=(vid did svid sdid)
        hba_vdss_raw=($("$sas3" list | grep -w "${hba_cid}" | awk '{print $3,$4,$6,$7}' | sed -e 's/h//g'))
        for ((i=0;i<${#hba_vdss_raw[@]};i++))
        do
            local length=$(echo ${#hba_vdss_raw[$i]})
            if [[ "$length" == "1" ]]
            then
                eval ${vdss[$i]}=$(echo "${hba_vdss_raw[$i]}" | sed 's/^/000/')
            elif [[ "$length" == "2" ]]
            then
                eval ${vdss[$i]}=$(echo "${hba_vdss_raw[$i]}" | sed 's/^/00/')
            elif [[ "$length" == "3" ]]
            then
                eval ${vdss[$i]}=$(echo "${hba_vdss_raw[$i]}" | sed 's/^/0/')
            else
                eval ${vdss[$i]}="${hba_vdss_raw[$i]}"
            fi
        done
        raid_identify_hba="0x$vid:0x$did:0x$svid:0x$sdid"
        match_raid=$(echo "${support_raid_infos[@]}" | grep -wi "$raid_identify_hba")
        if [ -z "$match_raid" ]
        then
            local error_code=3
            local description="HBA controller Numbers for $hba_cid card does not support"
            error_func $error_code "${description[*]}"
        fi
    done

    # Obtain all PMC card bus number
    all_pmc=($(lspci | grep -i "Adaptec" | awk '{print $1}'))
    for check_pmc in ${all_pmc[@]}
    do
        echo -e "\033[0;36m     PMC $check_pmc is found \033[0m" | tee -a $upgrade_log
        pmc_flag=1
        # Obtain the corresponding raid card VID DID SVID SDID
        vid=$(lspci -s ${check_pmc} -x | sed -n 2p | awk '{print $3$2}' | sed 's/^/0x/')
        did=$(lspci -s ${check_pmc} -x | sed -n 2p | awk '{print $5$4}' | sed 's/^/0x/')
        svid=$(lspci -s ${check_pmc} -x | sed -n 4p | awk '{print $15$14}' | sed 's/^/0x/')
        sdid=$(lspci -s ${check_pmc} -x | sed -n 4p | awk '{print $17$16}' | sed 's/^/0x/')
        raid_identify_pmc="$vid:$did:$svid:$sdid"
        match_raid=$(echo "${support_raid_infos[@]}" | grep -wi "$raid_identify_pmc")
        check_pmc_exist=$("$arcconf" list | egrep -io "Controller [0-9]+" | egrep -o "[0-9]+")
        if [ -z "$match_raid" ] && [ -n "$check_pmc_exist" ]
        then
            local error_code=3
            local description="PMC bus numbers for $check_pmc card does not support"
            error_func $error_code "${description[*]}"
        fi
        echo -e "\033[0;36m     PMC $raid_identify_pmc is found \033[0m" | tee -a $upgrade_log
    done

    [ -z "$arm_env" ] && return 0
    # Get all the hiraid card number
    HIRAID_CID=($("$hiraidadm" show allctrl | grep "Controller Id" | grep -Eo "[0-9]+"))
    for hiraid_cid in ${HIRAID_CID[@]}
    do
        hiraid_flag=1
        # Obtain the corresponding raid card VID DID SVID SDID
        hiraid_vdss_info="$("$hiraidadm" c${hiraid_cid} show status)"
        vid="0x"$(echo "$hiraid_vdss_info"| grep -w "Vendor Id" | awk -F "|" '{print $NF}' | grep -Po "\b.*\b")
        did="0x"$(echo "$hiraid_vdss_info"| grep -w "Device Id" | awk -F "|" '{print $NF}'  | grep -Po "\b.*\b")
        svid="0x"$(echo "$hiraid_vdss_info"| grep -w "SubVendor Id" | awk -F "|" '{print $NF}' | grep -Po "\b.*\b")
        sdid="$(echo "$hiraid_vdss_info"| grep -w "SubDevice Id" | awk -F "|" '{print $NF}' | grep -Po "\b.*\b")"
        sdid="0x"${sdid:1}
        raid_identify_hiraid="$vid:$did:$svid:$sdid"
        match_raid=$(echo "${support_raid_infos[@]}" | grep -wi "$raid_identify_hiraid")
        if [ -z "$match_raid" ]
        then
            local error_code=3
            local description="Hiraid controller Numbers for $hiraid_cid card does not support"
            error_func $error_code "${description[*]}"
        fi
        echo -e "\033[0;36m     Hiraid $hiraid_cid is found \033[0m" | tee -a $upgrade_log
    done
    return 0
}


# Check the raid driver
check_raid_drive()
{
    echo -e "\033[0;34m Raid drive is checking... \033[0m"
    local it_drive=$(lsmod | grep "mpt3sas")
    local megaraid_drive=$(lsmod | grep "megaraid_sas")

    # If no mpt3sas drive, the installation
    if [ -z "$it_drive" ]
    then
        local it_rpm="$currentdir/drives/$(ls $currentdir/drives | grep "mpt3sas")"
        rpm -Uvh $it_rpm
        modprobe mpt3sas
    fi
    # If no megaraid_sas drive, the installation
    if [ -z "$megaraid_drive" ]
    then
        local megaraid_rpm="$currentdir/drives/$(ls $currentdir/drives | grep "megaraid_sas")"
        rpm -Uvh $megaraid_rpm
        modprobe megaraid_sas
    fi

    sleep 2
    # Check the raid drive again
    if [ -n "$(lsmod | grep "mpt3sas")" ] && [ -n "$(lsmod | grep "megaraid_sas")" ]
    then
        echo "$(log_time) raid drive installed successfully" >> $upgrade_log
    else
        local error_code=9
        local description="raid drive installed failure"
        error_func $error_code "${description[*]}"
    fi
    return 0
}