#! /bin/bash

# Check the fw file
check_firmware()
{
    bin_fw_list=($(cat $currentdir/version.xml | grep "<FileName>" | sed -e 's/\///g' | awk -F "<FileName>" '{print $2}' | sed -e 's/,/ /g'))
    for fw_name in ${bin_fw_list[@]}
    do
        findfw=$(ls $currentdir/fw | grep "$fw_name")
        if [ -z "$findfw" ]
        then
            local error_code=2
            local description="Firmware or configure file invalid"
            error_func $error_code "${description[*]}"
        fi
    done
}