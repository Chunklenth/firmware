#! /bin/bash

  # Create log time
  log_time()
  {
      echo $(date +'%Y-%m-%d %H:%M:%S')
  }