#! /bin/bash

  # Create test results
  create_resultxml()
  {
      echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>" > "${currentdir}/result.xml"
      echo "<ConfigureResult>" >> "${currentdir}/result.xml"
      echo " <FwUpgrade>" >> "${currentdir}/result.xml"
      echo " <Result>${result}</Result>" >> "${currentdir}/result.xml"
      echo " <ErrorCode>${error_code}</ErrorCode>" >> "${currentdir}/result.xml"
      echo " <Description>${description}</Description>" >> "${currentdir}/result.xml"
      echo " </FwUpgrade>" >> "${currentdir}/result.xml"
      echo "</ConfigureResult>" >> "${currentdir}/result.xml"
  }