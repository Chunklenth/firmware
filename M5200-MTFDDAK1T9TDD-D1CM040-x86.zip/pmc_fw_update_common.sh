#! /bin/bash

# Upgrade SATA/SAS disk firmware under PMC
pmc_fw_update()
{
    local physical_loc=$1
    local raid_num=$2
    local eid=$(echo "$physical_loc" | awk -F "," '{print $1}')
    local slot=$(echo "$physical_loc" | awk -F "," '{print $2}')
    local sn=$("$arcconf" getconfig ${raid_num} pd $eid $slot | grep -wi "Serial number" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")

    if [[ "$curInterface" == "SATA" ]]
    then
    	local type_feature=$3
		# Because arcconf tools cannot complete access to the model and firmware, adopt indirect access here
    	local disk_name=$("$arcconf" getconfig ${raid_num} pd $eid $slot | grep -wi "Disk Name" | awk '{print $NF}')
    	if [ -z "$disk_name" ]
    	then
    	    # Access to Online mode corresponds to drive
    	    local disk_onln_arr=($("$arcconf" getconfig ${raid_num} ld | grep -wi "Disk Name" | grep -wi "/dev/sd." | awk '{print $NF}'))

    	    # PMC8060 card need accurate access to drive
    	    if [ -n "$disk_onln_arr" ] && [ "$type_feature" -eq 0 ]
    	    then
    	        # Choose the raid card under a logical drive letter, provide logical channel to retrieve information from a hard disk
    	        local disk_name="${disk_onln_arr[0]}"
    	    else
    	        # According to the model number of reverse matching logical drive
    	        local pmc_disk_model=$("$arcconf" getconfig ${raid_num} pd $eid $slot | grep -wi "Model" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
    	        local pmc_model_part=${pmc_disk_model::16}

    	        # Get all the logical drive of corresponding to the model
    	        local pmc_logic_volumn_arr=($("$sg_scan" -i | grep -wiB1 "$pmc_model_part" | grep -Po "/dev/sg(\d+)"))
    	        for pmc_logic_volumn_member in ${pmc_logic_volumn_arr[@]}
    	        do
    	            local sn_check=$("$sg_inq" --page=0x80 --export $pmc_logic_volumn_member | grep -wi "SCSI_IDENT_SERIAL" | awk -F "=" '{print $2}' | grep -Po "\b.*\b")
    	            if [ -n "$sn_check" ]
    	            then
    	                if [[ "$sn_check" == "$sn" ]]
    	                then
    	                    local disk_name="$pmc_logic_volumn_member"
    	                    break
    	                fi
    	            fi
    	        done
    	        if [ -z "$disk_name" ]
    	        then
    	            # Restore Raid background tasks
    	            resume_bt
    	            local error_code=8
    	            local description="logical_disk is not found under PMC [control_id:${raid_num}], result in get disk_model fail. Disk SN: $sn. $resume_res"
    	            error_func $error_code "${description[*]}"
    	        fi
    	    fi
    	fi
    	# PMC 8060 card information command : smartctl -i /dev/sgx
    	if [ "$type_feature" -ne 1 ]
    	then
    	    local all_channel=($($arcconf list ${raid_num} | grep -P "\d+,\d+" | grep -vi "Not Applicable" | egrep -o "[0-9]+,[0-9]+"))
    	    for ((number=0;number<${#all_channel[@]};number++))
    	    do
    	        if [[ "$physical_loc" == "${all_channel[$number]}" ]]
    	        then
    	            local disk_model=$("$smartool" -i --device=cciss,${number} ${disk_name} | grep -wi "Device Model" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
    	            local disk_firmware=$("$smartool" -i --device=cciss,${number} ${disk_name} | grep -wi "Firmware Version" | awk '{print $NF}')
    	            break
    	        fi
    	    done
    	else
    	    local disk_model=$("$smartool" -i ${disk_name} | grep -wi "Device Model" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
    	    local disk_firmware=$("$smartool" -i ${disk_name} | grep -wi "Firmware Version" | awk '{print $NF}')
    	fi
    else
    	local disk_firmware=$("$arcconf" getconfig ${raid_num} pd $eid $slot | grep -wi "Firmware" | awk '{print $NF}')
    	local disk_model=$("$arcconf" getconfig ${raid_num} pd $eid $slot | grep -wi "Model" | awk -F ":" '{print $2}' | grep -Po "\b.*\b")
    fi



    # Null check
    if [ -z "$disk_model" ] || [ -z "$disk_firmware" ]
    then
        # Restore Raid background tasks
        resume_bt
        local error_code=10
        local description="disk_firmware or disk_model that [${physical_loc}][Control_id:${raid_num}] is empty. Disk SN: $sn. $resume_res"
        error_func $error_code "${description[*]}"
    fi
    # Record scan on the disk
    echo "$disk_model : $disk_firmware" >> $currentdir/pmc_drive_list.txt

    # Check whether tested disk model number in version.xml
    local version_config=$currentdir/version.xml
    local dependent_model=$(cat $version_config | grep -i "<Dependency model=\"${disk_model}\"")
    if [ -n "$dependent_model" ]; then
    	local version_tmp=$(cat $currentdir/version.xml | grep -iF "<Dependency model=\"${disk_model}\"" | awk -F "matchXML=\"" '{print $2}' | awk -F "\"" '{print $1}')
    	local version_config=$currentdir/$version_tmp
    	local bin_fw_list=($(cat $version_config | grep "<FileName>" | sed -e 's/\///g' | awk -F "<FileName>" '{print $2}' | sed -e 's/,/ /g'))
    fi
    local disk_model_part=$(echo "$disk_model" | awk '{print $NF}')
    local model_check=$(cat $version_config | grep "<SupportModel>" | grep -i "$disk_model_part")
    if [ -n "$model_check" ]
    then
        find_disk=1
        # Check the tested disk whether the firmware is the latest
        local new_firmware=$(cat $version_config | grep "<Version>" | sed 's/\///g' | awk -F"<Version>" '{print $2}')
        local check_new=$(echo "$new_firmware" | grep -w "$disk_firmware")
        if [ -z "$check_new" ]
        then
            local old_version=$(cat $version_config | grep "<RuleOldVersion>" | awk -F "</?RuleOldVersion>" '{print $2}')
            # Check whether need to check old version
            if [[ "$old_version" != "NULL" ]];then
                # Check whether disk current firmware in the history list
                check_xml $disk_firmware $disk_model $physical_loc $sn $resume_res
                # Check XH disk current firmware in the history list
                local fwrule=$(cat $version_config | grep "<RuleOldVersion>" | awk -F "<RuleOldVersion>" '{print $2}' | awk -F ";" '{print $1}')
                local history_fw_check=$(echo "$fwrule" | egrep -wo "$disk_firmware")
                if [ -z "$history_fw_check" ]
                then
                    echo -e "The hard disk [model:$disk_model] is correct, but the hard disk firmware is not in the historical upgrade list." | tee -a $upgrade_log
                    return 0
                fi
            fi
            local vu_list=",HWE62ST3480L003N,HWE62ST3960L003N,HWE62ST31T9L003N,"
            local need_vu=$(echo "$vu_list" | grep ",$disk_model,")
            if [ -n "$need_vu" ]
			then
				send_vu_command $disk_firmware "pmc" $raid_num $physical_loc
			fi

            # Began to upgrade the firmware
            echo -e "\033[0;32m     start ${disk_model} update firmware \033[0m" | tee -a $upgrade_log
            for bin_fw in ${bin_fw_list[@]}
            do
                sleep 10
                # Upgrade command/check firmware is tried three times
                for ((n=1;n<4;n++))
                do
                    sleep 2
                    echo y | "$arcconf" imageupdate "$raid_num" device "$eid" "$slot" 32768 $currentdir/fw/${bin_fw} 7 Rescan > $upgrade_log 2>&1
                    if [ $? -eq 0 ]
                    then
                        echo "$(log_time) No.$n fw update ${bin_fw} command execute success for ${physical_loc} under PMC_RAID" | tee -a $upgrade_log
                    else
                        echo "$(log_time) No.$n fw update ${bin_fw} command execute failed for ${physical_loc} under PMC_RAID" | tee -a $upgrade_log
                        echo "No.$n fw update ${bin_fw} command execute failed for ${physical_loc} under PMC_RAID" >> $error_log
                    fi
                    # Before the query firmware, waiting for 10 s
                    sleep 10

                    [[ "$curInterface" == "SATA" ]] && local after_update_firmware=$("$smartool" -i --device=cciss,${number} ${disk_name} | grep -wi "Firmware Version" | awk '{print $NF}')
                    [[ "$curInterface" == "SAS" ]] && local after_update_firmware=$("$arcconf" getconfig ${raid_num} pd | grep -wA10 "$physical_loc" | grep -wi "Firmware" | awk '{print $NF}')

                    if [ -n "$after_update_firmware" ]
                    then
                        local check_fw=$(echo "${bin_fw}" | grep "$after_update_firmware")
                    fi
                    if [ "$after_update_firmware" == "$new_firmware" ]
                    then
                        echo "$(log_time) ${physical_loc} fw update to $new_firmware success SN: $sn" | tee -a $upgrade_log
                        break
                    elif [ -n "$check_fw" ]
                    then
                        echo "$(log_time) ${physical_loc} fw update to ${bin_fw} success SN: $sn" | tee -a $upgrade_log
                        break
                    elif [ $n -ge 3 ]
                    then
                        echo -e "\033[0;31m Model:${disk_model}[$physical_loc] SN:${sn} fw update to $new_firmware failed \033[0m" | tee -a $error_log
                        # Restore Raid background tasks
                        resume_bt
                        local error_code=7
                        local description="$(cat $error_log). $resume_res"
                        error_func $error_code "${description[*]}"
                    fi
                done
            done
            echo -e "\033[0;32m     finish ${disk_model} update firmware \033[0m" | tee -a $upgrade_log
        else
            echo -e "\033[0;32m     ${disk_model} : ${disk_firmware} is newest firmware \033[0m" | tee -a $upgrade_log
        fi
        return 0
    else
        echo -e "\033[0;32m     ${physical_loc}($disk_model) is not in the configuration,Skipping it... \033[0m" | tee -a $upgrade_log
    fi
    return 0
}